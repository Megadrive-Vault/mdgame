mdgame
======

Playing around with making a Sega Genesis game in C. SGDK is being used mostly as a build system and stub for the program, and most if not all interaction with the hardware is done with replacement C functions. By the end perhaps SGDK can be phased out.
