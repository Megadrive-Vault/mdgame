#ifndef BEZIER_H
#define BEZIER_H
#include "includes.h"

// Types and structs //
typedef struct point_diff point_diff;
struct point_diff
{
	int8_t x;
	int8_t y;
};

#endif
