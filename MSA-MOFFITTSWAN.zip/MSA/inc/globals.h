#ifndef GLOBALS_H
#define GLOBALS_H
#include <genesis.h>
#include "player.h"

#endif
