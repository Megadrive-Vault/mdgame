#ifndef _INSTRUMENT_RES_H_
#define _INSTRUMENT_RES_H_

extern const u8 instrument_chord[30];
extern const u8 instrument_bass[30];
extern const u8 instrument_lead[30];
extern const u8 instrument_bell[30];

#endif // _INSTRUMENT_RES_H_
