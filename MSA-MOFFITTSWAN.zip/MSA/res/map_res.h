#ifndef _MAP_RES_H_
#define _MAP_RES_H_

extern const u8 default_collision_map[1280];
extern const u8 default_foreground_map[1280];
extern const u8 alternate_collision_map[1280];
extern const u8 alternate_foreground_map[1280];
extern const u8 default_background_map[1280];
extern const u8 results_background_map[1280];
extern const u8 results_foreground_map[1280];
extern const u8 title_foreground_map[1280];
extern const u8 menu_foreground_map[1280];

#endif // _MAP_RES_H_
