#ifndef _GFX_RES_H_
#define _GFX_RES_H_

extern const u8 bg_tiles[32768];
extern const u8 fg_tiles[32768];
extern const u8 font_tiles[4432];
extern const u8 enemy_sprites[65586];
extern const u8 player_sprites[65536];

#endif // _GFX_RES_H_
