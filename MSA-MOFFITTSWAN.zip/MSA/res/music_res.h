#ifndef _MUSIC_RES_H_
#define _MUSIC_RES_H_

extern const u8 music__bgm[6020];
extern const u8 sfx__hit[110];
extern const u8 sfx__jump[66];
extern const u8 sfx__slap[44];
extern const u8 sfx__dash[210];
extern const u8 sfx__bounce[86];

#endif // _MUSIC_RES_H_
