cp ./xm2esf /usr/bin
cp ./loadxm_c/bin/linux/loadxm /usr/bin
cp ./esfopt/bin/linux/esfopt /usr/bin
